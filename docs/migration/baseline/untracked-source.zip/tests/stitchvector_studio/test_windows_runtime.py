"""Windows regressions: runtime resolution and project-local caches, not OCR quality."""
import json
import os
from pathlib import Path
import subprocess
import sys
from types import SimpleNamespace

from PIL import Image
import pytest

ROOT = Path(__file__).resolve().parents[2]
sys.path.insert(0, str(ROOT))
from tools.stitchvector_studio import registry
from tools.stitchvector_editor import core


@pytest.fixture(autouse=True)
def restore_process_runtime_settings(monkeypatch):
    import tempfile
    for name in ("TEMP", "TMP", "TMPDIR", "PADDLE_PDX_CACHE_HOME", "PADDLE_EXTENSION_DIR",
                 "HF_HOME", "XDG_CACHE_HOME", "MPLCONFIGDIR", "STITCHVECTOR_OCR_PY",
                 "PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK", "PYTHONUTF8"):
        monkeypatch.setenv(name, os.environ.get(name, ""))
    monkeypatch.setattr(tempfile, "tempdir", tempfile.tempdir)


@pytest.mark.parametrize("platform,relative,expected", [
    ("win32", ".venv-ocr/bin/python", ".venv-ocr/Scripts/python.exe"),
    ("win32", "runs/ocr_poc01/venvs/paddle/bin/python", "runs/ocr_poc01/venvs/paddle/Scripts/python.exe"),
    ("linux", ".venv-ocr/bin/python", ".venv-ocr/bin/python"),
])
def test_relative_python_is_project_local(monkeypatch, tmp_path, platform, relative, expected):
    monkeypatch.setattr(registry, "ROOT", tmp_path)
    monkeypatch.setattr(sys, "platform", platform)
    assert Path(registry.resolve_python({"python": relative})) == tmp_path / expected


def test_explicit_python_and_studio_are_preserved():
    assert registry.resolve_python({"python": "studio"}) == sys.executable
    assert registry.resolve_python({"python": sys.executable}) == sys.executable


def test_shipped_ocr_manifests_do_not_use_home_project_prefix():
    for name in ("paddleocr", "rapidocr"):
        manifest = json.loads((registry.PLUGIN_DIR / name / "manifest.json").read_text(encoding="utf-8"))
        assert not manifest["runtime"]["python"].startswith("geomap2arcgis/")
        assert not manifest["runtime"].get("model_cache", "").startswith("geomap2arcgis/")


def test_local_ocr_discovers_windows_environment(monkeypatch):
    monkeypatch.delenv("STITCHVECTOR_OCR_PY", raising=False)
    monkeypatch.setattr(sys, "platform", "win32")
    expected = ROOT / ".venv-ocr/Scripts/python.exe"
    original_exists = Path.exists
    monkeypatch.setattr(Path, "exists", lambda p: p == expected)
    monkeypatch.setattr(subprocess, "run", lambda *a, **k: SimpleNamespace(returncode=1))
    found, reason = core._ocr_python()
    assert found == expected, reason
    monkeypatch.setattr(Path, "exists", original_exists)


def test_local_ocr_relative_override_is_repository_relative(monkeypatch):
    monkeypatch.setenv("STITCHVECTOR_OCR_PY", ".venv-ocr/Scripts/python.exe")
    expected = ROOT / ".venv-ocr/Scripts/python.exe"
    monkeypatch.setattr(Path, "exists", lambda p: p == expected)
    assert core._ocr_python()[0] == expected


def test_runtime_temp_and_caches_are_project_local(monkeypatch, tmp_path):
    from tools.stitchvector_studio import runtime
    monkeypatch.setattr(runtime, "ROOT", tmp_path)
    keys = ("TEMP", "TMP", "TMPDIR", "PADDLE_PDX_CACHE_HOME",
            "PADDLE_EXTENSION_DIR", "HF_HOME", "XDG_CACHE_HOME", "MPLCONFIGDIR")
    for key in keys:
        monkeypatch.setenv(key, str(tmp_path.parent / "external-cache"))
    monkeypatch.setenv("STITCHVECTOR_OCR_PY", "invalid")
    import tempfile
    previous_temp = tempfile.tempdir
    try:
        runtime.configure_environment()
        import os
        for key in keys:
            assert Path(os.environ[key]).is_relative_to(tmp_path)
        assert Path(tempfile.gettempdir()).is_relative_to(tmp_path)
        assert Path(os.environ["STITCHVECTOR_OCR_PY"]).is_relative_to(tmp_path)
    finally:
        tempfile.tempdir = previous_temp


def test_sv_common_import_and_peak_memory_are_portable():
    result = subprocess.run(
        [sys.executable, "-c",
         "import sys; sys.path.insert(0,'experiments/STITCHVECTOR'); "
         "import sv_common; assert sv_common.peak_rss_gb() > 0"],
        cwd=ROOT, capture_output=True, text=True, encoding="utf-8",
    )
    assert result.returncode == 0, result.stderr


def test_sv_common_and_oracle_import_with_windows_default_encoding():
    source = """import builtins,sys
real_open=builtins.open
def cp936_open(file, mode='r', *args, **kw):
    if 'b' not in mode and 'encoding' not in kw:
        kw['encoding']='cp936'
    return real_open(file,mode,*args,**kw)
builtins.open=cp936_open
sys.path.insert(0,'experiments/STITCHVECTOR')
import sv_common,sv_oracle_v2
"""
    result = subprocess.run([sys.executable, "-c", source], cwd=ROOT, capture_output=True)
    assert result.returncode == 0, result.stderr.decode(errors="replace")


@pytest.mark.parametrize("platform,disabled", [("win32", True), ("linux", False)])
def test_paddle_uses_local_cache_and_windows_cpu_options(monkeypatch, tmp_path, platform, disabled):
    from tools.stitchvector_studio.plugins.paddleocr import plugin
    calls = []
    fake_engine = SimpleNamespace(predict=lambda im: [{"rec_polys": [], "rec_texts": [], "rec_scores": []}])
    def fake_paddle(**kwargs):
        calls.append(kwargs)
        return fake_engine
    monkeypatch.setitem(sys.modules, "paddleocr", SimpleNamespace(PaddleOCR=fake_paddle, __version__="test"))
    monkeypatch.setattr(sys, "platform", platform)
    assert plugin.CACHE == ROOT / "runs/ocr_poc01/cache/paddle"
    raster = tmp_path / "map.png"
    Image.new("RGB", (20, 20), "white").save(raster)
    descriptor = tmp_path / "raster.json"
    descriptor.write_text(json.dumps({"raster_artifact": str(raster)}), encoding="utf-8")
    context = SimpleNamespace(workdir=tmp_path, log=lambda msg: None)
    result = plugin.Plugin().run(context, {"raster": {"path": str(descriptor)}},
                                 {"scales": [1], "min_score": 0, "deduplicate": True, "geological_generic_rules": False})
    assert result.status == "OK"
    assert (calls[0].get("enable_mkldnn") is False) == disabled


def test_export_readback_temp_directories_are_local(monkeypatch, tmp_path):
    from tools.stitchvector_studio import exports
    from tools.stitchvector_studio import runtime
    monkeypatch.setattr(runtime, "ROOT", tmp_path)
    # Exercise a real empty SHP zip readback: a temporary extraction dir is still needed.
    import zipfile
    archive = tmp_path / "empty.zip"
    with zipfile.ZipFile(archive, "w") as z:
        z.writestr("field_mapping.json", "{}")
    seen = []
    original = exports.tempfile.TemporaryDirectory
    def record_temp(*args, **kwargs):
        assert kwargs.get("dir") is not None, "readback must not extract into a user temp directory"
        assert Path(kwargs["dir"]).is_relative_to(tmp_path)
        seen.append(kwargs["dir"])
        return original(*args, **kwargs)
    monkeypatch.setattr(exports.tempfile, "TemporaryDirectory", record_temp)
    assert exports.readback(archive, "SHP", {}, {"coordinate_mode": "PIXEL_SPACE"})["ok"]
    assert seen


def test_studio_api_response_does_not_fall_through_to_editor():
    import io
    from tools.stitchvector_studio import server
    handler = object.__new__(server.H)
    handler.path = "/api/studio/plugins"
    statuses = []
    handler.send_response = statuses.append
    handler.send_header = lambda *args: None
    handler.end_headers = lambda: None
    handler.wfile = io.BytesIO()
    handler.do_GET()
    assert statuses == [200], "one Studio request must produce exactly one HTTP response"


def test_disconnected_windows_client_is_handled():
    from tools.stitchvector_editor.server import H
    handler = object.__new__(H)
    handler.send_response = lambda *args: None
    handler.send_header = lambda *args: None
    handler.end_headers = lambda: None
    def disconnected(data):
        raise ConnectionAbortedError(10053, "client disconnected")
    handler.wfile = SimpleNamespace(write=disconnected)
    assert handler._send(200, {"ok": True}) is True
    assert handler.close_connection
