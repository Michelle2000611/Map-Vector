"""Project-local runtime directories shared by Studio and its OCR subprocesses."""
import os
from pathlib import Path
import sys
import tempfile

ROOT = Path(__file__).resolve().parents[2]
DEFAULT_WORKSPACE = ROOT / "runs/stitchvector/studio_v02/workspace"


def temporary_directory():
    path = ROOT / "runs/stitchvector/runtime/temp"
    path.mkdir(parents=True, exist_ok=True)
    return path


def configure_environment():
    """Keep Studio-generated temporary files and model caches in this checkout."""
    base = ROOT / "runs/stitchvector/runtime"
    temp = temporary_directory()
    paths = {
        "TEMP": temp, "TMP": temp, "TMPDIR": temp,
        "PADDLE_PDX_CACHE_HOME": ROOT / "runs/ocr_poc01/cache/paddle",
        "PADDLE_EXTENSION_DIR": base / "cache/paddle_extension",
        "HF_HOME": base / "cache/huggingface",
        "XDG_CACHE_HOME": base / "cache",
        "MPLCONFIGDIR": base / "cache/matplotlib",
    }
    for name, path in paths.items():
        path.mkdir(parents=True, exist_ok=True)
        os.environ[name] = str(path)
    suffix = "Scripts/python.exe" if sys.platform == "win32" else "bin/python"
    os.environ["STITCHVECTOR_OCR_PY"] = str(ROOT / ".venv-ocr" / suffix)
    os.environ["PADDLE_PDX_DISABLE_MODEL_SOURCE_CHECK"] = "True"
    os.environ["PYTHONUTF8"] = "1"
    tempfile.tempdir = str(temp)
